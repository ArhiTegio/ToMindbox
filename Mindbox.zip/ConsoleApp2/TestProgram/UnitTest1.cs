﻿using System;
using System.Collections.Generic;
using System.Drawing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using To_HH;

namespace TestProgram
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Круг_1()
        {
            var circle = new Circle(200);
            Assert.AreEqual(125663.7061435, circle.CalculationArea(), 1e-4);
        }
        [TestMethod]
        public void Круг_2()
        {
            var circle = new Circle(50);
            Assert.AreEqual(7853.9816, circle.CalculationArea(), 1e-4);
        }
        [TestMethod]
        public void Круг_3()
        {
            var circle = new Circle(10);
            circle.Radius = 10;
            Assert.AreEqual(314.1593, circle.CalculationArea(), 1e-4);
        }

        [TestMethod]
        public void Триугольник_1()
        {
            var tri = new Triangles(5,5,5);
            Assert.AreEqual(10.8253, tri.CalculationArea(), 1e-4);
            Assert.AreEqual(false, tri.IsRectangularTriangle());
        }

        [TestMethod]
        public void Триугольник_2()
        {
            var tri = new Triangles(25, 20, 15);
            Assert.AreEqual(150, tri.CalculationArea(), 1e-4);
            Assert.AreEqual(true, tri.IsRectangularTriangle());
        }

        [TestMethod]
        public void Триугольник_3()
        {
            var tri = new Triangles(30, 20, 15);
            Assert.AreEqual(133.3171, tri.CalculationArea(), 1e-4);
            Assert.AreEqual(false, tri.IsRectangularTriangle());
        }

        [TestMethod]
        public void Триугольник_4()
        {
            var tri = new Triangles(10, 13.747727084868, 17);
            Assert.AreEqual(68.73863542434, tri.CalculationArea(), 1e-4);
            Assert.AreEqual(true, tri.IsRectangularTriangle());
        }

        [TestMethod]
        public void ПолеТочек_1()
        {
            var fieldP = new PointField(new List<PointF>()
            {
                new PointF(){X = 0, Y = 0 },
                new PointF(){X = 1, Y = 0 },
                new PointF(){X = 1, Y = 1 },
                new PointF(){X = 0, Y = 1 },
            });
            Assert.AreEqual(1, fieldP.CalculationArea(), 1e-4);
        }

        [TestMethod]
        public void ПолеТочек_2()
        {
            var fieldP = new PointField(new List<PointF>()
            {
                new PointF(){X = 0, Y = 0 },
                new PointF(){X = 2, Y = 0 },
                new PointF(){X = 2, Y = 2 },
                new PointF(){X = 0, Y = 2 },
            });
            Assert.AreEqual(4, fieldP.CalculationArea(), 1e-4);
        }

        [TestMethod]
        public void ПолеТочек_3()
        {
            var fieldP = new PointField(new List<PointF>()
            {
                new PointF(){X = 0, Y = 0 },
                new PointF(){X = 4, Y = 0 },
                new PointF(){X = 4, Y = 4 },
                new PointF(){X = 0, Y = 4 },
            });
            Assert.AreEqual(16, fieldP.CalculationArea(), 1e-4);
        }

        [TestMethod]
        public void ПолеТочек_4()
        {
            var fieldP = new PointField(new List<PointF>()
            {
                new PointF(){X = 0,  Y = 0 },
                new PointF(){X = 12, Y = 0 },
                new PointF(){X = 12, Y = 12 },
                new PointF(){X = 0,  Y = 12 },
            });
            Assert.AreEqual(144, fieldP.CalculationArea(), 1e-4);
        }

        [TestMethod]
        public void ПолеТочек_5()
        {
            var fieldP = new PointField(new List<PointF>()
            {
                new PointF(){X = 0,  Y = 0  },
                new PointF(){X = 12, Y = 0  },
                new PointF(){X = 12, Y = 12 },
                new PointF(){X = 0,  Y = 12 },
                new PointF(){X = 6,  Y = 18 },
            });
            Assert.AreEqual(180, fieldP.CalculationArea(), 1e-4);
        }

        [TestMethod]
        public void ПолеТочек_6()
        {
            var fieldP = new PointField(new List<PointF>()
            {
                new PointF(){X = 0,  Y = 0  },
                new PointF(){X = 0,  Y = 12 },
                new PointF(){X = 12, Y = 12 },
                new PointF(){X = 12, Y = 0  },
                new PointF(){X = 10, Y = 0  },
                new PointF(){X = 10, Y = 10 },
                new PointF(){X = 2,  Y = 10 },
                new PointF(){X = 2,  Y = 0  },
            });
            Assert.AreEqual(64, fieldP.CalculationArea(), 1e-4);
        }

        [TestMethod]
        public void ПолеТочек_7()
        {
            var fieldP = new PointField(new List<PointF>()
            {
                new PointF(){X = 0,  Y = 0  },
                new PointF(){X = 0,  Y = 12 },
                new PointF(){X = 6,  Y = 18 },
                new PointF(){X = 12, Y = 12 },
                new PointF(){X = 12, Y = 0  },
                new PointF(){X = 10, Y = 0  },
                new PointF(){X = 10, Y = 10 },
                new PointF(){X = 10, Y = 12 },
                new PointF(){X = 2,  Y = 10 },
                new PointF(){X = 2,  Y = 0  },
            });
            Assert.AreEqual(96, fieldP.CalculationArea(), 1e-4);
        }
    }
}
