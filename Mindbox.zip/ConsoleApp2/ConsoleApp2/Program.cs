﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace To_HH
{
    public abstract class Figure
    {
        public abstract double CalculationArea();
    }

    public class Circle : Figure
    {
        private double radius = 0.0;

        public Circle(double radius)
        {
            this.radius = radius;
        }

        public double Radius { get => radius; set => radius = value; }

        public override double CalculationArea() => Math.PI * (radius * radius);
    }

    public class Triangles : Figure
    {
        private double sideA = 0.0;
        private double sideB = 0.0;
        private double sideC = 0.0;

        public Triangles(double sideA, double sideB, double sideC)
        {
            this.sideA = sideA;
            this.sideB = sideB;
            this.sideC = sideC;
        }

        public double SideA { get => sideA; set => sideA = value; }
        public double SideB { get => sideB; set => sideB = value; }
        public double SideC { get => sideC; set => sideC = value; }

        public override double CalculationArea()
        {
            var p = (sideA + sideB + sideC) / 2;
            return Math.Sqrt(p * (p - sideA) * (p - sideB) * (p - sideC));
        }

        public bool IsRectangularTriangle()
        {
            var a = Math.Round(180 * Math.Acos(((sideA * sideA) + (sideC * sideC) - (sideB * sideB)) / (2 * sideA * sideC)) / Math.PI, 1);
            var b = Math.Round(180 * Math.Acos(((sideA * sideA) + (sideB * sideB) - (sideC * sideC)) / (2 * sideA * sideB)) / Math.PI, 1);
            var c = 180 - a - b;
            return a == 90 || b == 90 || c == 90;
        }
    }

    public class PointField : Figure
    {
        private List<PointF> point = new List<PointF>();

        public PointField(List<PointF> point)
        {
            this.point = point;
        }

        public List<PointF> Point { get => point; set => point = value; }

        public override double CalculationArea()
        {
            var poly = new Polygon(point);
            var area = poly.getArea();
            return area;
        }
        
        class Polygon
        {
            private List<PointF> points; //вершины нашего многоугольника
            private Triangle[] triangles; //треугольники, на которые разбит наш многоугольник
            private bool[] taken; //была ли рассмотрена i-ая вершина многоугольника

            public Polygon(List<PointF> points) //points - х и y координаты
            {
                if (points.Count < 3)
                    //if (points.Count % 2 == 1 || points.Count < 3)
                    throw new Exception(); //ошибка, если не многоугольник

                this.points = points;

                triangles = new Triangle[this.points.Count - 2];

                taken = new bool[this.points.Count];

                triangulate(); //триангуляция
            }

            private void triangulate() //триангуляция
            {
                int trainPos = 0; //
                int leftPoints = points.Count; //сколько осталось рассмотреть вершин

                //текущие вершины рассматриваемого треугольника
                //int ci = findNextNotTaken(0);
                //int bi = findNextNotTaken(ci + 1);
                //int ai = findNextNotTaken(bi + 1);

                int ai = findNextNotTaken(0);
                int bi = findNextNotTaken(ai + 1);
                int ci = findNextNotTaken(bi + 1);

                int count = 0; //количество шагов

                while (leftPoints > 3) //пока не остался один треугольник
                {
                    //if (isLeft(points[ai], points[bi], points[ci]) && canBuildTriangle(ai, bi, ci)) //если можно построить треугольник
                    if (canBuildTriangle(ai, bi, ci)) //если можно построить треугольник
                    {
                        triangles[trainPos++] = new Triangle(points[ai], points[bi], points[ci]); //новый треугольник
                        taken[bi] = true; //исключаем вершину b
                        leftPoints--;
                        bi = ci;
                        ci = findNextNotTaken(ci + 1); //берем следующую вершину
                    }
                    else
                    { //берем следующие три вершины
                        ai = findNextNotTaken(ai + 1);
                        bi = findNextNotTaken(ai + 1);
                        ci = findNextNotTaken(bi + 1);
                    }

                    if (count > points.Count * points.Count)
                    { //если по какой-либо причине (например, многоугольник задан по часовой стрелке) триангуляцию провести невозможно, выходим
                        triangles = null;
                        break;
                    }

                    count++;
                }

                if (triangles != null) //если триангуляция была проведена успешно
                    triangles[trainPos] = new Triangle(points[ai], points[bi], points[ci]);
            }

            private int findNextNotTaken(int startPos) //найти следущую нерассмотренную вершину
            {
                startPos %= points.Count;
                if (!taken[startPos])
                    return startPos;

                int i = (startPos + 1) % points.Count;
                while (i != startPos)
                {
                    if (!taken[i])
                        return i;
                    i = (i + 1) % points.Count;
                }

                return -1;
            }

            private bool isLeft(PointF a, PointF b, PointF c) //левая ли тройка векторов
            {
                float abX = b.X - a.X;
                float abY = b.Y - a.Y;
                float acX = c.X - a.X;
                float acY = c.Y - a.Y;

                return abX * acY - acX * abY < 0;
            }

            private bool isPointInside(PointF a, PointF b, PointF c, PointF p) //находится ли точка p внутри треугольника abc
            {
                float ab = (a.X - p.X) * (b.Y - a.Y) - (b.X - a.X) * (a.Y - p.Y);
                float bc = (b.X - p.X) * (c.Y - b.Y) - (c.X - b.X) * (b.Y - p.Y);
                float ca = (c.X - p.X) * (a.Y - c.Y) - (a.X - c.X) * (c.Y - p.Y);

                return (ab >= 0 && bc >= 0 && ca >= 0) || (ab <= 0 && bc <= 0 && ca <= 0);
            }

            private bool canBuildTriangle(int ai, int bi, int ci) //false - если внутри есть вершина
            {
                for (int i = 0; i < points.Count; i++) //рассмотрим все вершины многоугольника
                    if (i != ai && i != bi && i != ci) //кроме троих вершин текущего треугольника
                        if (isPointInside(points[ai], points[bi], points[ci], points[i]))
                            return false;
                return true;
            }

            public List<PointF> getPoints() //возвращает вершины
            {
                return points;
            }

            public Triangle[] getTriangles() //возвращает треугольники
            {
                return triangles;
            }

            public double getArea() //подсчет площади
            {
                if (triangles == null)
                    return 0; //площадь нулевая, если триангуляция не удалась

                double s = 0;
                for (int i = 0; i < triangles.Length; i++) //суммируем площади для каждого треугольника
                    s += triangles[i].getArea();

                return Math.Round(s, 3);
            }

        }

        public class Triangle //треугольник
        {
            private PointF a, b, c;

            public Triangle(PointF a, PointF b, PointF c)
            {
                this.a = a;
                this.b = b;
                this.c = c;
            }

            public PointF getA()
            {
                return a;
            }

            public PointF getB()
            {
                return b;
            }

            public PointF getC()
            {
                return c;
            }

            public double getArea() //подсчет площади треугольника
            {
                //длины трех сторон
                double a = storona(this.a, this.b);
                double b = storona(this.b, this.c);
                double c = storona(this.c, this.a);

                double p = (a + b + c) / 2;
                var n = Math.Sqrt(p * (p - a) * (p - b) * (p - c)); //площадь по трем сторонам
                return n;
            }

            private double storona(PointF a, PointF b) //подсчет длины отрезка ab
            {
                float x = a.X - b.X;
                float y = a.Y - b.Y;
                return Math.Sqrt(x * x + y * y);
            }

        }
    }
}
